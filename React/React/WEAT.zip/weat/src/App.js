import './App.css';

function App() {
  return (
    <div className="WEAT" style={{backgroundColor: 'black'}}>
      <header className="WEAT-header">
        <img src={'./wireframe.png'} className="WEAT-logo" alt="logo" />
      </header>
    </div>
  );
}

export default App;
